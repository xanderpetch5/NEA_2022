import os
import json
import dataGathering
import csv
import time

directory = "C:\\Users\\xande\\PycharmProjects\\spotipy\\data"
songs_csv_file = 'songs.csv'

last_row_number = 0

if os.path.exists(songs_csv_file):
    with open(songs_csv_file, 'r', newline='',encoding="utf-8") as file:
        reader = csv.reader(file)
        next(reader, None)
        for row in reader:
            last_row_number += 1
print(f"Last row number: {last_row_number}")


num_files = len(os.listdir(directory))
num_playlists = num_files * 1000

count = 0
playlist_count= 0


for filename in os.listdir(directory):
    if filename.endswith(".json"):
        print(filename)
        file_path = os.path.join(directory, filename)
        with open(file_path, "r") as f:
            data = json.load(f)
        playlists = data['playlists']
        track_count = 0

        for playlist in playlists:
            playstart = time.time()
            playlist_count += 1
            tracks = playlist['tracks']
            print(f"New playlist: {playlist_count}")
            for track in tracks:
                track_count += 1
                if track_count <= last_row_number:
                    print(f"Skipping track {track_count} (last row number: {last_row_number})")
                    continue
                start_time = time.time()
                song = dataGathering.SongForDataset(track['track_uri'], "uri")
                with open(songs_csv_file, mode='a', encoding="utf-8", newline='') as file:
                    writer = csv.writer(file)
                    if last_row_number == 0:
                        writer.writerow(
                            ["Track ID", "Hash"])
                    writer.writerow(song.format_data())
                    end_time = time.time()
                    print(f"time taken: {end_time-start_time}, playlist {playlist_count}, track number {track_count}")
                last_row_number += 1

            play_end = time.time()
            print(f"\nPlaylist processed in {play_end-playstart}, {round((playlist_count/1000000) * 100,4)}% processed\n")