import sqlite3
import hashlib

class Database:
    def __init__(self, filename):
        # Connect to the database file
        self.datab = sqlite3.connect(filename)

        # Store the connection in the self.datab attribute
        self.cursor = self.datab.cursor()

    def add_user(self, username, password):
        # Check if the username exists in the table
        if not self.check_repeat(username):
            # Hash the password
            password_hash = hashlib.sha256(password.encode()).hexdigest()

            # Find the maximum id value in the table
            self.cursor.execute("SELECT MAX(id) FROM users")
            max_id = self.cursor.fetchone()[0]

            # Insert the new user into the
            try:
                self.cursor.execute("INSERT INTO users (id, name, password, user_history) VALUES (?,?,?,?)", (max_id + 1, username, password_hash,''))
            except:
                self.cursor.execute("INSERT INTO users (id, name, password, user_history) VALUES (?,?,?,?)",
                                    (1, username, password_hash,''))
            self.datab.commit()
            print('user added')
        else:
            print('repeat detected')

    def check_repeat(self, username):
        # Query the database for an entry with the specified username
        result = self.cursor.execute("SELECT 1 FROM users WHERE name = ?", (username,))

        # Check if any rows were returned
        if result.fetchone():
            return True
        else:
            return False

    def check_credentials(self, username, password):
        password_hash = hashlib.sha256(password.encode()).hexdigest()

        result = self.cursor.execute(
            "SELECT * FROM users WHERE name = ? AND password = ?",
            (username, password_hash))

        if result.fetchone():
            return True
        else:
            return False

    def delete_user(self, username, password):
        # Hash the password
        password_hash = hashlib.sha256(password.encode()).hexdigest()

        # Query the database for an entry with the specified username and password
        result = self.datab.execute(
            "SELECT * FROM users WHERE name = ? AND password = ?",
            (username, password_hash))

        # Check if any rows were returned
        user = result.fetchone()
        if user:
            # Get the id of the user that is being deleted
            user_id = user[0]
            print(user_id)
            # Delete the user from the table
            self.cursor.execute("DELETE FROM users WHERE name=? AND password=?", (username, password_hash))

            # Iterate every user with an id higher than the one deleted down by one
            self.datab.execute("UPDATE users SET id = id - 1 WHERE id > ?", (user_id,))
            self.datab.commit()
            print(f'User {username} deleted')
        else:
            print('User not found')

    def fetch_history(self, username):
        self.cursor.execute('SELECT user_history FROM users WHERE name=?', (username,))

        result = self.cursor.fetchone()

        # If a result was returned, return the user history
        if result:
            return result[0]
        else:
            return None

    def update_history(self, username, new_history):
        # Update the user history for the specified username
        self.cursor.execute('UPDATE users SET user_history=? WHERE name=?', (new_history, username))

        # Commit the changes to the database
        self.datab.commit()

    def change_password(self, username, new_password):
        # Hash the new password
        new_password_hash = hashlib.sha256(new_password.encode()).hexdigest()

        # Update the password for the specified username
        self.cursor.execute('UPDATE users SET password=? WHERE name=?', (new_password_hash, username))

        self.datab.commit()

    def close_database(self):
        self.datab.close()

